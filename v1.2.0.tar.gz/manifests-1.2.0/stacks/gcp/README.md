gcp
==================================================

# NAME

  gcp

# SYNOPSIS

  kubectl apply --recursive -f gcp

# Description

sample description

# SEE ALSO

